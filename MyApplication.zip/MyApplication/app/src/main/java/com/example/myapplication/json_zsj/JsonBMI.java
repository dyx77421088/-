package com.example.myapplication.json_zsj;

import android.os.AsyncTask;

import com.example.myapplication.json_zsj.model_zsj.BMI;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class JsonBMI extends AsyncTask<String, Integer, String> {
    private int weight, height, sex;

    public JsonBMI(int height, int weight, int sex, OnHuiDiao hui) {
        this.height = height;
        this.weight = weight;
        this.sex = sex;
        this.hui = hui;
        execute("http://api.tianapi.com/txapi/bmi/index");
    }

    @Override
    protected String doInBackground(String... strings) {

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "key=cb9e6171f4509f20f9c0264b831540f6&height=" + height +
                "&weight=" + weight +
                "&sex=" + sex);
        Request request = new Request.Builder()
                .url(strings[0])
                .method("POST", body)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .build();
        try {
            Response response = client.newCall(request).execute();
            return response.body().string();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        System.out.println(s);

        BMI bmi = new Gson().fromJson(s, new TypeToken<BMI>(){}.getType());

        System.out.println(bmi);
        if(hui != null) {
            hui.onHui(bmi);
        }
    }

    private OnHuiDiao hui;

    public interface OnHuiDiao{
        void onHui(BMI xz);
    }
}
