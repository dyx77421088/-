package com.example.myapplication.ui_zsj.Q3;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.example.myapplication.R;
import com.example.myapplication.ui_zsj.Q3.adapter_zsj.MyAdapter2;
import com.example.myapplication.ui_zsj.Q3.model_zsj.Phone;

import java.util.List;

public class ItemLayout extends LinearLayout {

    private ViewHolder holder;
    private Context context;

    public ItemLayout(Context context) {
        this(context, null);
    }

    public ItemLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        View.inflate(context, R.layout.item_q3, this);
        holder = new ViewHolder(this);
    }

    public void setZimu(String zimu) {
        holder.tvZimu.setText(zimu);
    }

    public void setList(List<Phone> list) {

        int num = list.size();
        ViewGroup.LayoutParams layoutParams = holder.listDisplay.getLayoutParams();
        layoutParams.height = 210 * num;
        holder.listDisplay.setLayoutParams(layoutParams);
        holder.listDisplay.setAdapter(new MyAdapter2(context, list));
    }

    private static
    class ViewHolder {
        public View rootView;
        public TextView tvZimu;
        public ListView listDisplay;

        public ViewHolder(View rootView) {
            this.rootView = rootView;
            this.tvZimu = rootView.findViewById(R.id.tv_zimu);
            this.listDisplay = rootView.findViewById(R.id.list_display);
        }

    }
}
