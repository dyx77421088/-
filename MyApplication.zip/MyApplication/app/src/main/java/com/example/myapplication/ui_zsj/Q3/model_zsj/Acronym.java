package com.example.myapplication.ui_zsj.Q3.model_zsj;

import java.util.List;

/**
 * 首字母缩写分组
 */
public class Acronym {
    private String acronym;
    private List<Phone> phones;

    public Acronym(String acronym, List<Phone> phones) {
        this.acronym = acronym;
        this.phones = phones;
    }

    public String getAcronym() {
        return acronym;
    }

    public void setAcronym(String acronym) {
        this.acronym = acronym;
    }

    public List<Phone> getPhones() {
        return phones;
    }

    public void setPhones(List<Phone> phones) {
        this.phones = phones;
    }

    @Override
    public String toString() {
        return "Acronym{" +
                "acronym='" + acronym + '\'' +
                ", phones=" + phones +
                '}' + "\n";
    }
}
