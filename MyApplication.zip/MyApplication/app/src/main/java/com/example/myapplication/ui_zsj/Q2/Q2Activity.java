package com.example.myapplication.ui_zsj.Q2;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.myapplication.MyAppCompatActivity;
import com.example.myapplication.R;

public class Q2Activity extends MyAppCompatActivity implements View.OnClickListener {

    private EditText etHeight;
    private EditText etWeight;
    private Button btSelect;
    private RadioButton rb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q2);
        initView();
    }

    private void initView() {
        etHeight = findViewById(R.id.et_height);
        etWeight = findViewById(R.id.et_weight);
        btSelect = findViewById(R.id.bt_select);
        rb = findViewById(R.id.rb_1);

        btSelect.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_select:
                submit();
                break;
        }
    }

    private void submit() {
        // validate
        String height = etHeight.getText().toString().trim();
        if (TextUtils.isEmpty(height)) {
            Toast.makeText(this, "height不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        String weight = etWeight.getText().toString().trim();
        if (TextUtils.isEmpty(weight)) {
            Toast.makeText(this, "weight不能为空", Toast.LENGTH_SHORT).show();
            return;
        }
        int sex = rb.isChecked() ? 0 : 1;
        Intent intent = new Intent(this, Q2_2Activity.class);
        intent.putExtra("height", Integer.parseInt(height));
        intent.putExtra("weight", Integer.parseInt(weight));
        intent.putExtra("sex", sex);
        startActivity(intent);
    }
}
