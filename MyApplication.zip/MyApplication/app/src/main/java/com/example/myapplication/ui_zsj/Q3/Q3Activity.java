package com.example.myapplication.ui_zsj.Q3;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.ListView;

import com.example.myapplication.MyAppCompatActivity;
import com.example.myapplication.R;
import com.example.myapplication.ui_zsj.Q3.adapter_zsj.MyAdapter;
import com.example.myapplication.ui_zsj.Q3.model_zsj.Acronym;
import com.example.myapplication.ui_zsj.Q3.model_zsj.Phone;
import com.example.myapplication.util_zsj.ChineseUtil;

import java.util.ArrayList;
import java.util.List;

public class Q3Activity extends MyAppCompatActivity {
    private ListView listDisplay;
//    private CharacterParser characterParser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q3);
        initView();
    }

    private void initView() {
        listDisplay = findViewById(R.id.list_display);

        List<Phone> inf = getInf();
        List<Acronym> acronyn = getAcronyn(inf);
        System.out.println(inf);
        System.out.println(acronyn);
        listDisplay.setAdapter(new MyAdapter(this, acronyn));
    }

    private String[] zimus = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z",};

    /**
     * 给phone分类
     * @param phones
     * @return
     */
    private List<Acronym> getAcronyn(List<Phone> phones) {
        List<Acronym> list = new ArrayList<>();
        for(int i = 0; i < zimus.length; ++i) {
            String zimu = zimus[i];
            List<Phone> p = new ArrayList<>();
            for (int j = 0; j < phones.size(); j++) {
                //获取首字母缩写
                String sx = ChineseUtil.getFirstLetter(phones.get(j).getName());
                //根据首字母缩写分组
                if(zimu.equals(sx)) {
                    p.add(phones.get(j));
                }
            }
            System.out.println(p);
            if(p.size() > 0) {
                list.add(new Acronym(zimu, p));
            }
        }
        return list;
    }

    /**
     * 获得用户信息
     */
    private List<Phone> getInf() {

        List<Phone> phones = new ArrayList<>();
        //联系人数据库中的列名
        Uri URI = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String NAME = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME;
        String PHONE = ContactsContract.CommonDataKinds.Phone.NUMBER;
        //查询系统数据库，获取全部联系人
        Cursor cursor = getContentResolver().query(URI, null, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                //根据列名获得值
                String name = cursor.getString(cursor.getColumnIndex(NAME));//名字
                String number = cursor.getString(cursor.getColumnIndex(PHONE));//电话号
//                System.out.println("name = " + name + " 电话 = " + number);

                //添加
                if (name != null && number != null) {
                    phones.add(new Phone(name, number));
                }
            }
        }
        return phones;
    }
}
