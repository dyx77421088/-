package com.example.myapplication.json_zsj.model_zsj;

import java.util.List;

/**
 {
 "code": 200,
 "msg": "success",
 "newslist": [
 {
 "bmi": 12,
 "normbmi": "18.5~23.9",
 "idealweight": 84,
 "normweight": "75.6~92.4",
 "healthy": "风险极高",
 "tip": "严重偏瘦，请注意加强锻炼和休息，必要时请体检就医。"
 }
 ]
 }
 */
public class BMI {
    private String code;
    private String msg;
    private List<News> newslist;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public List<News> getNewslist() {
        return newslist;
    }

    public void setNewslist(List<News> newslist) {
        this.newslist = newslist;
    }

    public class News {
        /**
         * "bmi": 12,
         *  "normbmi": "18.5~23.9",
         *  "idealweight": 84,
         *  "normweight": "75.6~92.4",
         *  "healthy": "风险极高",
         *  "tip": "严重偏瘦，请注意加强锻炼和休息，必要时请体检就医。"
         */
        public String bmi;
        public String normbmi;
        public String idealweight;
        public String normweight;
        public String healthy;
        public String tip;



        public String getNormbimi() {
            return normbmi;
        }

        public void setNormbimi(String normbimi) {
            this.normbmi = normbimi;
        }

        public String getBmi() {
            return bmi;
        }

        public void setBmi(String bmi) {
            this.bmi = bmi;
        }

        public String getIdealweight() {
            return idealweight;
        }

        public void setIdealweight(String idealweight) {
            this.idealweight = idealweight;
        }

        public String getNormweight() {
            return normweight;
        }

        public void setNormweight(String normweight) {
            this.normweight = normweight;
        }

        public String getHealthy() {
            return healthy;
        }

        public void setHealthy(String healthy) {
            this.healthy = healthy;
        }

        public String getTip() {
            return tip;
        }

        public void setTip(String tip) {
            this.tip = tip;
        }

        @Override
        public String toString() {
            return "News{" +
                    "bmi='" + bmi + '\'' +
                    ", normbimi='" + normbmi + '\'' +
                    ", idealweight=" + idealweight +
                    ", normweight='" + normweight + '\'' +
                    ", healthy='" + healthy + '\'' +
                    ", tip='" + tip + '\'' +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "BMI{" +
                "code='" + code + '\'' +
                ", msg='" + msg + '\'' +
                ", newsList=" + newslist +
                '}';
    }
}
