package com.example.myapplication.ui_zsj.Q3.adapter_zsj;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.example.myapplication.ui_zsj.Q3.ItemLayout;
import com.example.myapplication.ui_zsj.Q3.model_zsj.Acronym;

import java.util.List;

public class MyAdapter extends BaseAdapter {
    private Context context;
    private List<Acronym> data;

    public MyAdapter(Context context) {
        this.context = context;
    }

    public MyAdapter(Context context, List<Acronym> data) {
        this.data = data;
        this.context = context;
    }

    public void setData(List<Acronym> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return data == null ? 0 : data.size();
    }

    @Override
    public Acronym getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ItemLayout layout;
        if(convertView == null) {
            convertView = new ItemLayout(context);
        }
        layout = (ItemLayout) convertView;

        Acronym item = getItem(position);
        layout.setZimu(item.getAcronym());
        layout.setList(item.getPhones());
        return layout;
    }
}
