package com.example.myapplication.ui_zsj.Q4;

import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ListView;

import com.example.myapplication.MyAppCompatActivity;
import com.example.myapplication.R;
import com.example.myapplication.ui_zsj.Q4.adapter_zsj.MyAdapter;
import com.example.myapplication.ui_zsj.Q4.model_zsj.SmsInf;

import java.util.ArrayList;
import java.util.List;

public class Q4Activity extends MyAppCompatActivity {

    private ListView listDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q4);
        initView();
    }

    private void initView() {
        listDisplay = findViewById(R.id.list_display);
        listDisplay.setAdapter(new MyAdapter(this, getSmsInf()));
    }

    private List<SmsInf> getSmsInf() {
        List<SmsInf> infs = new ArrayList<>();
        Uri uri = Uri.parse("content://sms/");
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                //时间
                long date = cursor.getLong(cursor.getColumnIndex("date"));
                //号码
                String address = cursor.getString(cursor.getColumnIndex("address"));
                //内容
                String body = cursor.getString(cursor.getColumnIndex("body"));

                infs.add(new SmsInf(date, address, body));
            }
        }

        return infs;
    }

}
