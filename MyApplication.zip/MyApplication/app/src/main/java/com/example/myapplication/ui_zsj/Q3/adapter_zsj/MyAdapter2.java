package com.example.myapplication.ui_zsj.Q3.adapter_zsj;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.myapplication.R;
import com.example.myapplication.ui_zsj.Q3.model_zsj.Phone;

import java.util.List;

public class MyAdapter2 extends BaseAdapter {
    private List<Phone> phones;
    private Context context;

    public MyAdapter2(Context context) {
        this.context = context;
    }

    public MyAdapter2(Context context, List<Phone> phones) {
        this.phones = phones;
        this.context = context;
    }

    public void setPhones(List<Phone> phones) {
        this.phones = phones;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return phones == null ? 0 : phones.size();
    }

    @Override
    public Phone getItem(int position) {
        return phones.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view;
        if(convertView == null) {
            convertView = View.inflate(context, R.layout.item_item_q3, null);
        }

        view = convertView;

        final Phone item = getItem(position);
        TextView name = view.findViewById(R.id.name);
        name.setText(item.getName());
        final TextView number = view.findViewById(R.id.number);
        number.setText(item.getNumber());
        //拨打电话按钮
        Button button = view.findViewById(R.id.bt_gn);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println(item.getNumber());
                context.startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + item.getNumber())));
            }
        });
        return view;
    }
}
