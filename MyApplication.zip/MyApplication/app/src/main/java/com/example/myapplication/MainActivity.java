package com.example.myapplication;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.myapplication.ui_zsj.Q1.Q1Activity;
import com.example.myapplication.ui_zsj.Q2.Q2Activity;
import com.example.myapplication.ui_zsj.Q3.Q3Activity;
import com.example.myapplication.ui_zsj.Q4.Q4Activity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    private Button bt1;
    private Button bt2;
    private Button bt3;
    private Button bt4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        //设置权限
        setQuanXian();
        bt1 = findViewById(R.id.bt_1);
        bt2 = findViewById(R.id.bt_2);
        bt3 = findViewById(R.id.bt_3);
        bt4 = findViewById(R.id.bt_4);

        bt1.setOnClickListener(this);
        bt2.setOnClickListener(this);
        bt3.setOnClickListener(this);
        bt4.setOnClickListener(this);
    }

    /**
     * 按钮的跳转
     */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_1:
                startActivity(new Intent(this, Q1Activity.class));
                break;
            case R.id.bt_2:
                startActivity(new Intent(this, Q2Activity.class));
                break;
            case R.id.bt_3:
                //如果没有这个权限先设置权限
                if(checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    System.out.println("设置权限");
                    new AlertDialog.Builder(this)
                            .setMessage("缺少权限")
                            .setPositiveButton("设置", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    setQuanXian();
                                }
                            })
                            .setNegativeButton("取消", null)
                            .show();
                } else {//如果有读取联系人信息的权限才进去
                    startActivity(new Intent(this, Q3Activity.class));
                }
                break;
            case R.id.bt_4:
                if(checkSelfPermission(Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                    setQuanXian();
                } else {//如果有读取信息的权限才进去
                    startActivity(new Intent(this, Q4Activity.class));
                }
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.quanxian, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add_quanxian:
                Toast.makeText(this, "添加权限", Toast.LENGTH_SHORT).show();
                setQuanXian();
                break;
            case R.id.setting_quanxian:
                //打开系统的应用管理
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                Uri uri = Uri.fromParts("package", MainActivity.this.getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void setQuanXian() {
        ActivityCompat.requestPermissions(this,
                new String[]{
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.READ_SMS
                },
                1);
    }
}














