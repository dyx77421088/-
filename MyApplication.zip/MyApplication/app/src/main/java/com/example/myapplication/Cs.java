package com.example.myapplication;

public class Cs {
    public static void main(String[] args) {
        for(char ch = 'A'; ch <= 'Z'; ++ch) {
            System.out.print("\""+ch+"\",");
        }
    }
}
