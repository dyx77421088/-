package com.example.myapplication.ui_zsj.Q4.model_zsj;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SmsInf {
    private String date;
    private String number;
    private String body;

    public SmsInf(String date, String number, String body) {
        this.date = date;
        this.number = number;
        this.body = body;
    }

    public SmsInf(long date, String number, String body) {
        SimpleDateFormat simple = new SimpleDateFormat("yyyy年MM月dd日 hh:mm:ss");
        this.date = simple.format(new Date(date));
        this.number = number;
        this.body = body;
    }

    @Override
    public String toString() {
        return "SmsInf{" +
                "date='" + date + '\'' +
                ", number='" + number + '\'' +
                ", body='" + body + '\'' +
                '}';
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }
}
