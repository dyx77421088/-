package com.example.myapplication.ui_zsj.Q1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;


import com.example.myapplication.MyAppCompatActivity;
import com.example.myapplication.R;

public class Q1Activity extends MyAppCompatActivity implements AdapterView.OnItemSelectedListener, View.OnClickListener {

    private Spinner sp1;
    private Spinner sp2;
    private Spinner sp3;
    private ArrayAdapter yearAdapter;
    private ArrayAdapter monthAdapter;
    private ArrayAdapter<CharSequence> dayAdapter28;
    private ArrayAdapter<CharSequence> dayAdapter29;
    private ArrayAdapter<CharSequence> dayAdapter30;
    private ArrayAdapter<CharSequence> dayAdapter31;
    private Button buSelect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q1);

        initAdapter();
        initView();

//        new JsonBMI(171, 45, 0);
    }

    public void initAdapter() {
        yearAdapter = ArrayAdapter.createFromResource(this, R.array.year, R.layout.support_simple_spinner_dropdown_item);
        monthAdapter = ArrayAdapter.createFromResource(this, R.array.month, R.layout.support_simple_spinner_dropdown_item);
        dayAdapter28 = ArrayAdapter.createFromResource(this, R.array.day_28, R.layout.support_simple_spinner_dropdown_item);
        dayAdapter29 = ArrayAdapter.createFromResource(this, R.array.day_29, R.layout.support_simple_spinner_dropdown_item);
        dayAdapter30 = ArrayAdapter.createFromResource(this, R.array.day_30, R.layout.support_simple_spinner_dropdown_item);
        dayAdapter31 = ArrayAdapter.createFromResource(this, R.array.day_31, R.layout.support_simple_spinner_dropdown_item);
    }

    private void initView() {
        sp1 = findViewById(R.id.sp1);
        sp2 = findViewById(R.id.sp2);
        sp3 = findViewById(R.id.sp3);


        sp1.setAdapter(yearAdapter);
        sp2.setAdapter(monthAdapter);

        sp1.setOnItemSelectedListener(this);
        sp2.setOnItemSelectedListener(this);

        buSelect = findViewById(R.id.bu_select);
        buSelect.setOnClickListener(this);
    }

    /**
     * 根据年月获得该年中有多少天
     */
    public int getDay(int year, int month) {
        if (month < 1 || month > 12) return -1;
        int[] a = {-1, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if (month != 2)
            return a[month];
        return a[2] + (year % 4 == 0 && year % 100 != 0 || year % 400 == 0 ? 1 : 0);
    }

    /**
     * 根据天数获得对应的adapter
     */
    public ArrayAdapter getAdapterToDay(int day) {
        if (day == 28) {
            return dayAdapter28;
        } else if (day == 29) {
            return dayAdapter29;
        } else if (day == 30) {
            return dayAdapter30;
        } else if (day == 31) {
            return dayAdapter31;
        }
        return null;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        int year = Integer.parseInt(sp1.getSelectedItem().toString());
        int month = Integer.parseInt(sp2.getSelectedItem().toString());
        int day = getDay(year, month);

        sp3.setAdapter(getAdapterToDay(day));
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bu_select:
                int year = Integer.parseInt(sp1.getSelectedItem().toString());
                int month = Integer.parseInt(sp2.getSelectedItem().toString());
                int day = Integer.parseInt(sp3.getSelectedItem().toString());

                //带参数跳转
                Intent intent = new Intent(Q1Activity.this, Q1_2Activity.class);
                intent.putExtra("year", year);
                intent.putExtra("month", month);
                intent.putExtra("day", day);
                startActivity(intent);
                break;
        }
    }
}














