package com.example.myapplication.json_zsj.model_zsj;

import java.util.List;

public class XingZuo {
//    "code": 200,
//            "msg": "success",
    private String code;
    private String msg;
    private List<News> newslist;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public List<News> getNewslist() {
        return newslist;
    }

    public void setNewslist(List<News> newslist) {
        this.newslist = newslist;
    }

    public class News {
        private String type;
        private String content;

        public News(String type, String content) {
            this.type = type;
            this.content = content;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        @Override
        public String toString() {
            return "XingZuo{" +
                    "type='" + type + '\'' +
                    ", content='" + content + '\'' +
                    '}';
        }
    }

    @Override
    public String toString() {
        return "XingZuo{" +
                "code='" + code + '\'' +
                ", msg='" + msg + '\'' +
                ", newslist=" + newslist +
                '}';
    }
}
