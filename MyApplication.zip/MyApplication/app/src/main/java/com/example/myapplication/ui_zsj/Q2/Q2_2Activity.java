package com.example.myapplication.ui_zsj.Q2;

import android.os.Bundle;
import android.widget.TextView;

import com.example.myapplication.json_zsj.model_zsj.BMI;
import com.example.myapplication.json_zsj.JsonBMI;
import com.example.myapplication.MyAppCompatActivity;
import com.example.myapplication.R;

import java.util.List;

public class Q2_2Activity extends MyAppCompatActivity {

    private TextView tvBmi;
    private TextView tvNormbmi;
    private TextView tvIdealweight;
    private TextView tvNormweight;
    private TextView tvHealthy;
    private TextView tvTip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q2_2);
        initView();


    }

    private void initView() {
        tvBmi = findViewById(R.id.tv_bmi);
        tvNormbmi = findViewById(R.id.tv_normbmi);
        tvIdealweight = findViewById(R.id.tv_idealweight);
        tvNormweight = findViewById(R.id.tv_normweight);
        tvHealthy = findViewById(R.id.tv_healthy);
        tvTip = findViewById(R.id.tv_tip);

        int height = getIntent().getIntExtra("height", -1);
        int weight = getIntent().getIntExtra("weight", -1);
        int sex = getIntent().getIntExtra("sex", -1);

        new JsonBMI(height, weight, sex, new JsonBMI.OnHuiDiao() {
            @Override
            public void onHui(BMI bmi) {
                List<BMI.News> list = bmi.getNewslist();
                BMI.News news = list.get(0);

                tvBmi.setText(news.bmi);
                tvNormbmi.setText(news.normbmi);
                tvIdealweight.setText(news.idealweight);
                tvNormweight.setText(news.normweight);
                tvHealthy.setText(news.healthy);
                tvTip.setText(news.tip);
            }
        });
    }
}
