package com.example.myapplication.json_zsj;

import android.os.AsyncTask;

import com.example.myapplication.json_zsj.model_zsj.XingZuo;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class JsonXingZuo extends AsyncTask<String, Integer, String> {
    private OkHttpClient client = new OkHttpClient();
    /**
     * aries 白羊座,
     * taurus 金牛座,
     * gemini 双子座,
     * cancer 钜蟹座,
     * leo 狮子座,
     * virgo 处女座,
     * libra 天平座,
     * scorpio 天蝎座,
     * sagittarius 射手座,
     * capricorn ,摩羯座,
     * aquarius 水瓶座,
     * pisces 双鱼座。
     * <p>
     * <p>
     * "白羊座",	03月21日─04月20日	火	        "Aries",
     * "金牛座",	04月21日─05月20日	土	        "Taurus",
     * "双子座",	05月21日─06月21日	空气	    "Gemini",
     * "巨蟹座",	06月22日─07月22日	水	        "Cancer",
     * "狮子座",	07月23日─08月22日	火	        "Leo",
     * "处女座",	08月23日─09月22日	土	        "Virgo",
     * "天秤座",	09月23日─10月22日	空气	    "Libra",
     * "天蝎座",	10月23日─11月21日	水	        "Scorpio",
     * "射手座",	11月22日─12月21日	火	        "Sagittarius",
     * "摩羯座",	12月22日─01月19日	土	        "Capricorn",
     * "水瓶座",	01月20日─02月18日	空气	    "Aquarius",
     * "双鱼座",	02月19日─03月20日	水	        "Pisces",
     */
    private String xingZuo;

    public JsonXingZuo(String xingZuo, OnHuiDiao hui) {
        this.xingZuo = xingZuo;
        this.hui = hui;
        execute("http://api.tianapi.com/txapi/star/index");
    }

    @Override
    protected String doInBackground(String... strings) {

        OkHttpClient client = new OkHttpClient().newBuilder()
                .build();
        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType, "key=cb9e6171f4509f20f9c0264b831540f6&astro=" + xingZuo);
        Request request = new Request.Builder()
                .url(strings[0])
                .method("POST", body)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .build();
        try {
            Response response = client.newCall(request).execute();
            return response.body().string();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

        System.out.println(s);

        XingZuo xz = new Gson().fromJson(s, new TypeToken<XingZuo>() {
        }.getType());

        System.out.println(xz);
        if(hui != null) {
            hui.onHui(xz);
        }
    }

    private OnHuiDiao hui;

    public interface OnHuiDiao{
        void onHui(XingZuo xz);
    }
}
