package com.example.myapplication.ui_zsj.Q1;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.json_zsj.JsonXingZuo;
import com.example.myapplication.MyAppCompatActivity;
import com.example.myapplication.R;
import com.example.myapplication.json_zsj.model_zsj.XingZuo;

import java.util.List;

public class Q1_2Activity extends MyAppCompatActivity {
    private String[] shengxiao =
            {"鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪"};
    private int[] shengxiaoImg = {
            R.drawable.shu,
            R.drawable.niu,
            R.drawable.hu,
            R.drawable.tu,
            R.drawable.long2,
            R.drawable.she,
            R.drawable.ma,
            R.drawable.yang,
            R.drawable.hou,
            R.drawable.ji,
            R.drawable.gou,
            R.drawable.zhu,
    };
    private String[] xingzuo =
            {"白羊座", "金牛座", "双子座", "巨蟹座", "狮子座", "处女座", "天秤座",
                    "天蝎座", "射手座", "摩羯座", "水瓶座", "双鱼座",};
    private String[] xingzuoE =
            {"aries", "taurus", "gemini", "cancer", "leo", "virgo", "libra",
                    "scorpio", "sagittarius", "capricorn", "aquarius", "pisces",};
    private int[] xingzuoImg = {
            R.drawable.baiyang,
            R.drawable.jingniu,
            R.drawable.shuangzi,
            R.drawable.juxie,
            R.drawable.shizi,
            R.drawable.chunv,
            R.drawable.tianping,
            R.drawable.tianxie,
            R.drawable.sheshou,
            R.drawable.mojie,
            R.drawable.shuiping,
            R.drawable.shuangyu,
    };
    private TextView tvShengxiao;
    private ImageView ivShengxiao;
    private TextView tvXingzuo;
    private ImageView ivXingzuo;
    private TextView yunshi;
    private TextView tvTime;
    private TextView[] tvYunShi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q1_2);
        initView();
    }

    private void initView() {
        int year = getIntent().getIntExtra("year", 1900);
        int month = getIntent().getIntExtra("month", 1);
        int day = getIntent().getIntExtra("day", 1);
        tvTime = findViewById(R.id.tv_time);
        tvShengxiao = findViewById(R.id.tv_shengxiao);
        ivShengxiao = findViewById(R.id.iv_shengxiao);
        tvXingzuo = findViewById(R.id.tv_xingzuo);
        ivXingzuo = findViewById(R.id.iv_xingzuo);
        yunshi = findViewById(R.id.yunshi);
        tvYunShi = new TextView[]{
                findViewById(R.id.tv_yunshi1),
                findViewById(R.id.tv_yunshi2),
                findViewById(R.id.tv_yunshi3),
                findViewById(R.id.tv_yunshi4),
                findViewById(R.id.tv_yunshi5),
                findViewById(R.id.tv_yunshi6),
                findViewById(R.id.tv_yunshi7),
                findViewById(R.id.tv_yunshi8),
                findViewById(R.id.tv_yunshi9),
        };

        //设置时间
        String time = year + "年" + month + "月" + day + "日";
        tvTime.setText(time);
        //设置生肖和名字
        tvShengxiao.setText(shengxiao[(year - 1900) % 12]);
        ivShengxiao.setImageResource(shengxiaoImg[(year - 1900) % 12]);
        //设置星座
        int index = getXingZuoIndex(month, day);//根据日期获得星座
        String str = xingzuo[index] + "(" + xingzuoE[index] +  ")";
        tvXingzuo.setText(str);
        ivXingzuo.setImageResource(xingzuoImg[index]);
        //设置今日运势
        String s = xingzuo[index]+"的今日运势";
        yunshi.setText(s);
        /*根据接口获得今日运势**/
        new JsonXingZuo(xingzuoE[index], new JsonXingZuo.OnHuiDiao() {
            @Override
            public void onHui(XingZuo xz) {
                List<XingZuo.News> list = xz.getNewslist();
                for (int i = 0; i < list.size(); i++) {
                    tvYunShi[i].setText(list.get(i).getContent());
                }
            }
        });
    }
/*** "白羊座",	03月21日─04月20日	火	        "Aries",
 * "金牛座",	04月21日─05月20日	土	        "Taurus",
 * "双子座",	05月21日─06月21日	空气	    "Gemini",
 * "巨蟹座",	06月22日─07月22日	水	        "Cancer",
 * "狮子座",	07月23日─08月22日	火	        "Leo",
 * "处女座",	08月23日─09月22日	土	        "Virgo",
 * "天秤座",	09月23日─10月22日	空气	    "Libra",
 * "天蝎座",	10月23日─11月21日	水	        "Scorpio",
 * "射手座",	11月22日─12月21日	火	        "Sagittarius",
 * "摩羯座",	12月22日─01月19日	土	        "Capricorn",
 * "水瓶座",	01月20日─02月18日	空气	    "Aquarius",
 * "双鱼座",	02月19日─03月20日	水	        "Pisces",
 */
    private int getXingZuoIndex(int month, int day) {
        if(month == 3 && day >= 21 || month == 4 && day <= 20) {
            return 0;
        } else if(month == 4 || month == 5 && day <= 20) {
            return 1;
        } else if(month == 5 || month == 6 && day <= 21) {
            return 2;
        } else if(month == 6 || month == 7 && day <= 22) {
            return 3;
        } else if(month == 7 || month == 8 && day <= 22) {
            return 4;
        } else if(month == 8 || month == 9 && day <= 22) {
            return 5;
        } else if(month == 9 || month == 10 && day <= 22) {
            return 6;
        } else if(month == 10 || month == 11 && day <= 21) {
            return 7;
        } else if(month == 11 || month == 12 && day <= 21) {
            return 8;
        } else if(month == 12 || month == 1 && day <= 19) {
            return 9;
        } else if(month == 1 || month == 2 && day <= 18) {
            return 10;
        } else if(month == 2 || month == 3) {
            return 11;
        }
        return -1;
    }
}
