package com.example.myapplication.ui_zsj.Q4.adapter_zsj;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.myapplication.R;
import com.example.myapplication.ui_zsj.Q4.model_zsj.SmsInf;

import java.util.List;

public class MyAdapter extends BaseAdapter {
    private Context context;
    private List<SmsInf> data;

    public MyAdapter(Context context, List<SmsInf> data) {
        this.context = context;
        this.data = data;
    }

    @Override
    public int getCount() {
        return data == null ? 0 : data.size();
    }

    @Override
    public SmsInf getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null) {
            convertView = View.inflate(context, R.layout.item_q4, null);
            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        SmsInf item = getItem(position);
        holder.tvDate.setText(item.getDate());
        holder.tvNumber.setText(item.getNumber());
        holder.tvBody.setText(item.getBody());
        return convertView;
    }

    private static
    class ViewHolder {
        public View rootView;
        public TextView tvDate;
        public TextView tvNumber;
        public TextView tvBody;

        public ViewHolder(View rootView) {
            this.rootView = rootView;
            this.tvDate = (TextView) rootView.findViewById(R.id.tv_date);
            this.tvNumber = (TextView) rootView.findViewById(R.id.tv_number);
            this.tvBody = (TextView) rootView.findViewById(R.id.tv_body);
        }

    }
}
