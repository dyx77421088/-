package com.example.abc_hz_20191229.layout;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import com.example.abc_hz_20191229.R;

public class DelLayout extends LinearLayout {

    private ViewHolder holder;

    public DelLayout(Context context) {
        this(context, null);
    }

    public DelLayout(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        View.inflate(context, R.layout.caozuo, this);
        holder = new ViewHolder(this);
        holder.tvTitle.setText("删除");
        holder.tvInf.setText("删除文件会同时删除该文件夹下的所有文件.\n确定要删除马？");
        holder.etShuru.setVisibility(GONE);

        holder.btNo.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(myClick != null) {
                    myClick.onNo();
                }
            }
        });

        holder.btOk.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(myClick != null) {
                    myClick.onOk();
                }
            }
        });
    }

    public void setInf(String inf) {
        holder.tvInf.setText(inf);
    }

    private OnClick myClick;

    public void setMyClick(OnClick myClick) {
        this.myClick = myClick;
    }

    public interface OnClick {
        void onNo();
        //删除
        void onOk();
    }

    private static
    class ViewHolder {
        public View rootView;
        public TextView tvTitle, tvInf;
        public EditText etShuru;
        public Button btNo;
        public Button btOk;

        public ViewHolder(View rootView) {
            this.rootView = rootView;
            this.tvTitle = rootView.findViewById(R.id.tv_title);
            this.tvInf = rootView.findViewById(R.id.tv_inf);
            this.etShuru = (EditText) rootView.findViewById(R.id.et_shuru);
            this.btNo = (Button) rootView.findViewById(R.id.bt_no);
            this.btOk = (Button) rootView.findViewById(R.id.bt_ok);
        }

    }
}
