package com.example.abc_hz_20191229.layout;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;

import com.example.abc_hz_20191229.util.MyFileUtils;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MyChart extends PieChart {
    public MyChart(Context context) {
        this(context, null);
    }

    public MyChart(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    /**
     * 第一个是用了的内存，第二个是还剩下的内存
     */
    public void setFloat(List<Float> floats) {
        String[] names = {"已用内存", "可用内存"};
        List<PieEntry> entries = new ArrayList<>();
        float sum = 0;

        for (int i = 0; i < floats.size(); ++i) {
            entries.add(new PieEntry(floats.get(i), names[i]));
            sum += floats.get(i);
        }

        PieDataSet set = new PieDataSet(entries, "");
        set.setColors(Color.rgb(190, 10, 10), Color.rgb(10, 160, 10));

        PieData data = new PieData(set);
        setData(data);


//        setDrawHoleEnabled(false);
        setTouchEnabled(false);//取消触摸监听
        setHoleRadius(60);
        setCenterTextSize(30);
        setCenterText("已用:\n" + getYiYong(sum, floats.get(0)));
        setDrawEntryLabels(false);//设置不画entryLabels
//        setEntryLabelColor(Color.TRANSPARENT);//设置为透明色

        Legend legend = getLegend();
        legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.CENTER);
        legend.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        legend.setFormSize(20);
        legend.setYOffset(30);

        Description description = getDescription();
        description.setXOffset(20);
        description.setYOffset(30);
        description.setTextSize(20);
        float l = floats.get(1);
        description.setText("可用内存:"+MyFileUtils.getSizeString((long) l)+"\t\t总内存:" + MyFileUtils.getSizeString((long) sum));

        data.setValueTextColor(Color.BLACK);
        data.setValueTextSize(24);

        set.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return MyFileUtils.getSizeString((long) value);
            }
        });
    }

    /**
     * 获得占比
     */
    private String getYiYong(float sum, Float aFloat) {
        DecimalFormat format = new DecimalFormat("#.00");
        return format.format(aFloat / sum * 100) + "%";
    }
}
