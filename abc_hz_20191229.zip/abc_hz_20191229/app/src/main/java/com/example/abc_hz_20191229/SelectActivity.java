package com.example.abc_hz_20191229;

import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.abc_hz_20191229.adapter.MyAdapter;
import com.example.abc_hz_20191229.layout.NewFileLayout;
import com.example.abc_hz_20191229.model.MyFile;
import com.example.abc_hz_20191229.util.MyFileUtils;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class SelectActivity extends AppCompatActivity implements View.OnClickListener {

    private ListView listDisplay;
    private String thePath;
    private List<MyFile> show;
    private MyAdapter adapter;
    private LinearLayout llCopy;
    private LinearLayout llClose;
    private LinearLayout llMore;
    private String path;
    private boolean isCopy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);
        setTitle("移动到...");
        initView();

        path = getIntent().getStringExtra("path");
        //是否为拷贝的
        isCopy = getIntent().getBooleanExtra("isCopy", false);
        if(isCopy) {
            setTitle("复制到...");
        }
    }

    private void initView() {
        listDisplay = findViewById(R.id.list_display);
        llCopy = findViewById(R.id.ll_copy);
        llClose = findViewById(R.id.ll_close);
        llMore = findViewById(R.id.ll_more);

        listDisplay = findViewById(R.id.list_display);

        thePath = Environment.getExternalStorageDirectory().getAbsolutePath();
        show = MyFileUtils.show(new File(thePath));
        //默认排序
        Collections.sort(show, MyFileUtils.getSort());
        adapter = new MyAdapter(this, show);
        listDisplay.setAdapter(adapter);

        //设置单击后的监听
        listDisplay.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //如果它不是文件夹，不能点进去
                if (!show.get(position).isDirectory()) {
                    Toast.makeText(SelectActivity.this, "" + show.get(position).getName(), Toast.LENGTH_SHORT).show();
                    return;
                }
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                thePath = show.get(position).getPath() + "/" + show.get(position).getName();
                updateListView();
            }
        });

        //给图片设置监听
        llCopy.setOnClickListener(this);
        llClose.setOnClickListener(this);
        llMore.setOnClickListener(this);
    }

    private void updateListView() {
        //如果是根目录就不能回退了
        if (Environment.getExternalStorageDirectory().getAbsolutePath().equals(thePath)) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        }
        //重新获取文件
        show = MyFileUtils.show(new File(thePath));
        Collections.sort(show, MyFileUtils.getSort());
        //设置
        adapter.setData(show);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            //单击回退按钮
            case android.R.id.home:
                thePath = getLastPath();
                updateListView();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * 获得上一层路径
     */
    private String getLastPath() {
        return thePath.substring(0, thePath.lastIndexOf("/"));
    }

    private String getLastPath(String path) {
        return path.substring(0, path.lastIndexOf("/"));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_copy:
                if(thePath.indexOf(path) == 0 || getLastPath(path).equals(thePath)) {
                    Toast.makeText(this, "失败", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "成功!!!!!!!!", Toast.LENGTH_SHORT).show();
                    if(new File(path).isDirectory()) {//如果拷贝的东西是文件夹就先创建文件夹
                        String name = path.substring(path.lastIndexOf("/"));
                        new File(thePath + name).mkdirs();//创建文件夹
                        MyFileUtils.copy(path, thePath + name);//拷贝

                    } else {
                        MyFileUtils.copy(path, thePath);//拷贝
                    }
                    if(!isCopy) {//如果不是拷贝就要删除之前的
                        //删除之前的
                        MyFileUtils.deleteFile(new File(path));
                    }
                }
                finish();
                break;
            case R.id.ll_close:
                finish();
                break;
            case R.id.ll_more:
                showPopupMenu(llMore);
                break;
        }
    }


    private void showPopupMenu(View view) {
        // View当前PopupMenu显示的相对View的位置
        PopupMenu popupMenu = new PopupMenu(this, view);
        // menu布局
        popupMenu.getMenuInflater().inflate(R.menu.more, popupMenu.getMenu());
        // menu的item点击事件
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.new_file:
                        createFile();
                        break;
                }
                return false;
            }
        });
        popupMenu.show();
    }

    private void createFile() {
        NewFileLayout newFileLayout = new NewFileLayout(this);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(newFileLayout)
                .show();
        newFileLayout.setMyCheck(new NewFileLayout.OnCheck() {
            @Override
            public void onCheckNo() {
                dialog.dismiss();
            }

            @Override
            public void onCheckOk(String input) {
                dialog.dismiss();

                File file = new File(thePath + "/" + input);
                //创建文件夹
                if (MyFileUtils.hasFile(show, input, true)) {
                    Toast.makeText(SelectActivity.this, "同名文件夹", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!file.mkdirs()) {
                    Toast.makeText(SelectActivity.this, "格式不对", Toast.LENGTH_SHORT).show();
                }

                updateListView();
            }
        });
    }
}
