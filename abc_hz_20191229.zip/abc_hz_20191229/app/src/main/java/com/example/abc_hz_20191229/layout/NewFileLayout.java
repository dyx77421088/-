package com.example.abc_hz_20191229.layout;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.abc_hz_20191229.R;

public class NewFileLayout extends LinearLayout {

    private ViewHolder holder;

    public NewFileLayout(Context context) {
        this(context, null);
    }

    public NewFileLayout(final Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        View.inflate(context, R.layout.caozuo, this);
        holder = new ViewHolder(this);

        holder.btNo.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(myCheck != null) {
                    myCheck.onCheckNo();
                }
            }
        });

        holder.btOk.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if(myCheck != null) {
                    if(TextUtils.isEmpty(getInput())) {
                        Toast.makeText(context, "文件夹不能为空", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    myCheck.onCheckOk(getInput());
                }
            }
        });
    }
    public void setTitle(String title) {
        holder.tvTitle.setText(title);
    }

    public void setInf(String inf) {
        holder.tvInf.setText(inf);
    }

    /**
     * 获得输入的内容
     */
    public String getInput() {
        return holder.etShuru.getText().toString();
    }

    private OnCheck myCheck;

    public void setMyCheck(OnCheck myCheck) {
        this.myCheck = myCheck;
    }



    public interface OnCheck {
        //单击取消按钮的监听
        void onCheckNo();
        //单击确定按钮的监听
        void onCheckOk(String input);
    }

    private static
    class ViewHolder {
        public View rootView;
        public TextView tvTitle, tvInf;
        public EditText etShuru;
        public Button btNo;
        public Button btOk;

        public ViewHolder(View rootView) {
            this.rootView = rootView;
            this.tvTitle = rootView.findViewById(R.id.tv_title);
            this.tvInf = rootView.findViewById(R.id.tv_inf);
            this.etShuru = (EditText) rootView.findViewById(R.id.et_shuru);
            this.btNo = (Button) rootView.findViewById(R.id.bt_no);
            this.btOk = (Button) rootView.findViewById(R.id.bt_ok);
        }

    }
}
