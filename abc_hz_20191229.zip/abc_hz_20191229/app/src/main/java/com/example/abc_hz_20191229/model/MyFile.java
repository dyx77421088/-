package com.example.abc_hz_20191229.model;

import java.io.Serializable;

public class MyFile implements Serializable {
    //名字
    private String name;
    //描述
    private String bottom;
    //图片
    private int img;
    //是否为文件夹
    private boolean isDirectory;
    //大小
    private long size;
    //路径
    private String path;

    public MyFile(String name, String bottom, int img, boolean isDirectory, long size, String path) {
        this.name = name;
        this.bottom = bottom;
        this.img = img;
        this.isDirectory = isDirectory;
        this.size = size;
        this.path = path;
    }

    @Override
    public String toString() {
        return "MyFile{" +
                "name='" + name + '\'' +
                ", bottom='" + bottom + '\'' +
                ", img=" + img +
                ", isDirectory=" + isDirectory +
                ", size=" + size +
                ", path='" + path + '\'' +
                '}';
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public long getSize() {
        return size;
    }

    public void setSize(long size) {
        this.size = size;
    }

    public boolean isDirectory() {
        return isDirectory;
    }

    public void setDirectory(boolean directory) {
        isDirectory = directory;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBottom() {
        return bottom;
    }

    public void setBottom(String bottom) {
        this.bottom = bottom;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
