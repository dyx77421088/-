package com.example.abc_hz_20191229.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.abc_hz_20191229.R;
import com.example.abc_hz_20191229.model.MyFile;

import java.util.List;

public class MyAdapter extends BaseAdapter {
    private Context context;
    private List<MyFile> data;

    public MyAdapter(Context context, List<MyFile> data) {
        this.context = context;
        this.data = data;
    }

    public void setData(List<MyFile> data) {
        this.data = data;
        //通知更新
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return data == null ? 0 : data.size();
    }

    @Override
    public MyFile getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = View.inflate(context, R.layout.item, null);
        ViewHolder holder = new ViewHolder(view);

        MyFile item = getItem(position);
        //设置该文件的图片
        holder.img.setImageResource(item.getImg());
        //设置名字
        holder.tvName.setText(item.getName());
        //设置描述
        holder.tvBottom.setText(item.getBottom());
        if(!item.isDirectory()) {//如果是非文件夹，隐藏右边的图标
            //隐藏非文件夹的东西
            holder.imgRight.setVisibility(View.GONE);
        }
        return view;
    }

    //工具，接收传过来的布局中的组件
    private static
    class ViewHolder {
        public View rootView;
        public ImageView img;
        public TextView tvName;
        public TextView tvBottom;
        public ImageView imgRight;

        public ViewHolder(View rootView) {
            this.rootView = rootView;
            this.img = rootView.findViewById(R.id.img);
            this.tvName = rootView.findViewById(R.id.tv_name);
            this.tvBottom = rootView.findViewById(R.id.tv_bottom);
            this.imgRight = rootView.findViewById(R.id.img_right);
        }

    }
}
