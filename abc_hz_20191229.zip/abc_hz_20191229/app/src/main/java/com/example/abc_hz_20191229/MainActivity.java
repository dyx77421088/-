package com.example.abc_hz_20191229;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.abc_hz_20191229.adapter.MyAdapter;
import com.example.abc_hz_20191229.layout.DelLayout;
import com.example.abc_hz_20191229.layout.NewFileLayout;
import com.example.abc_hz_20191229.model.MyFile;
import com.example.abc_hz_20191229.util.MyFileUtils;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listDisplay;
    private MyAdapter adapter;
    private List<MyFile> show;
    //当前文件的路径
    private String thePath;
    //记录排序规则
    private int type = -1;
    private boolean isShengXu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("文件管理");
        setQuanXian();
    }

    private void initView() {
        listDisplay = findViewById(R.id.list_display);

        thePath = Environment.getExternalStorageDirectory().getAbsolutePath();
        show = MyFileUtils.show(new File(thePath));
        //默认排序
        Collections.sort(show, MyFileUtils.getSort());
        adapter = new MyAdapter(this, show);
        listDisplay.setAdapter(adapter);

        //设置单击后的监听
        listDisplay.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //如果它不是文件夹，不能点进去
                if (!show.get(position).isDirectory()) {
                    Toast.makeText(MainActivity.this, "" + show.get(position).getName(), Toast.LENGTH_SHORT).show();
                    return;
                }
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                thePath = show.get(position).getPath() + "/" + show.get(position).getName();
                updateListView(-1, false);
            }
        });

        //注册上下文监听
        registerForContextMenu(listDisplay);
    }

    /**
     * 修改listView的东西
     * 回退的话保留上一次的排序规则
     */
    private void updateListView(int type, boolean isShengXu) {
        //如果是根目录就不能回退了
        if(Environment.getExternalStorageDirectory().getAbsolutePath().equals(thePath)) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        }
        //重新获取文件
        show = MyFileUtils.show(new File(thePath));
        if(type != -1) {
            Collections.sort(show, MyFileUtils.getSort(type, isShengXu));
        } else {//默认排序
            Collections.sort(show, MyFileUtils.getSort());
        }
        //设置
        adapter.setData(show);

//        File file = new File("");
//        file.delete();
    }

    /**
     * 当页面跳转回来的时候调用的回调
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        //更新数据
        updateListView(type, isShengXu);
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.caozuo, menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        //这个item的名字
        final String name = show.get(info.position).getName();
        switch (item.getItemId()) {
            case R.id.caozuo_del:
//                Toast.makeText(this, "删除=>  " + name, Toast.LENGTH_SHORT).show();
                DelLayout layout = new DelLayout(this);
                if(!show.get(info.position).isDirectory()) {//如果是非文件夹直接提示删除
                    layout.setInf("确定要删除该文件吗？");
                }
                final AlertDialog dialog = new AlertDialog.Builder(this)
                        .setView(layout)
                        .show();


                layout.setMyClick(new DelLayout.OnClick() {
                    @Override
                    public void onNo() {
                        dialog.dismiss();
                    }

                    @Override
                    public void onOk() {
                        dialog.dismiss();
                        String path = thePath + "/" + name;
                        //删除
                        MyFileUtils.deleteFile(new File(path));
                        updateListView(type, isShengXu);
                    }
                });
                break;

                //移动操作
            case R.id.caozuo_move:
                Intent intent = new Intent(this, SelectActivity.class);
                intent.putExtra("path", thePath + "/" + name);
                startActivityForResult(intent, 1);
                break;
            case R.id.caozuo_copy:
                Intent it = new Intent(this, SelectActivity.class);
                it.putExtra("path", thePath + "/" + name);
                it.putExtra("isCopy", true);
                startActivityForResult(it, 1);
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.quanxian, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            //单击回退按钮
            case android.R.id.home:
                thePath = getLastPath();
                updateListView(type, isShengXu);
                //清除上一次的排序规则
                type = -1;
                break;
            case R.id.add_quanxian:
                Toast.makeText(this, "添加权限", Toast.LENGTH_SHORT).show();
                setQuanXian();
                break;
            case R.id.setting_quanxian:
                //打开系统的应用管理
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                Uri uri = Uri.fromParts("package", MainActivity.this.getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
                break;
            case R.id.sort_0_sheng:
                Collections.sort(show, MyFileUtils.getSort(0, true));
                adapter.setData(show);
                type = 0;isShengXu = true;
                break;
            case R.id.sort_0_jiang:
                Collections.sort(show, MyFileUtils.getSort(0, false));
                adapter.setData(show);
                type = 0;isShengXu = false;
                break;
            case R.id.sort_1_sheng:
                Collections.sort(show, MyFileUtils.getSort(1, true));
                adapter.setData(show);
                type = 1;isShengXu = true;
                break;
            case R.id.sort_1_jiang:
                Collections.sort(show, MyFileUtils.getSort(1, false));
                adapter.setData(show);
                type = 1;isShengXu = false;
                break;
                //新建文件夹
            case R.id.new_file:
                createFile(true);
                break;
            case R.id.new_file2:
                createFile(false);
                break;
            case R.id.show:
                startActivity(new Intent(this, ShowNeiCunActivity.class));
        }
        return super.onOptionsItemSelected(item);
    }

    private void createFile(final boolean wenJianJia) {
        NewFileLayout newFileLayout = new NewFileLayout(this);
        if(!wenJianJia) {
            newFileLayout.setInf("请输入文件名称");
            newFileLayout.setTitle("新建文件");
        }
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setView(newFileLayout)
                .show();
        newFileLayout.setMyCheck(new NewFileLayout.OnCheck() {
            @Override
            public void onCheckNo() {
                dialog.dismiss();
            }

            @Override
            public void onCheckOk(String input) {
                Toast.makeText(MainActivity.this, "" + input, Toast.LENGTH_SHORT).show();
                dialog.dismiss();

                File file = new File(thePath + "/" + input);
                //创建文件夹
                if(wenJianJia) {
                    if (MyFileUtils.hasFile(show, input, true)) {
                        Toast.makeText(MainActivity.this, "同名文件夹", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if(!file.mkdirs()) {
                        Toast.makeText(MainActivity.this, "格式不对", Toast.LENGTH_SHORT).show();
                    }
                } else {//创建文件
                    if (MyFileUtils.hasFile(show, input, false)) {
                        Toast.makeText(MainActivity.this, "同名文件", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    try {
                        if(!file.createNewFile()) {
                            Toast.makeText(MainActivity.this, "格式不对", Toast.LENGTH_SHORT).show();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                updateListView(type, isShengXu);
            }
        });
    }

    /**
     * 获得上一层路径
     */
    private String getLastPath() {
        return thePath.substring(0, thePath.lastIndexOf("/"));
    }

    private void setQuanXian() {
        ActivityCompat.requestPermissions(this,
                new String[]{
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                },
                1);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == 1) {
            initView();
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}
