package com.example.abc_hz_20191229;

import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.abc_hz_20191229.layout.MyChart;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ShowNeiCunActivity extends AppCompatActivity {

    private MyChart mychart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_nei_cun);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        initView();
    }

    private void initView() {
        mychart = findViewById(R.id.mychart);
        long shengyu = getAvailableInternalMemorySize();
        long sum = getTotalInternalMemorySize();
        List<Float> floats = new ArrayList<>();
        floats.add((float) (sum - shengyu));
        floats.add((float) shengyu);
        mychart.setFloat(floats);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * 获取手机内部剩余存储空间
     *
     * @return
     */
    public static long getAvailableInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        return availableBlocks * blockSize;
    }

    /**
     * 获取手机内部总的存储空间
     *
     * @return
     */
    public static long getTotalInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long totalBlocks = stat.getBlockCount();
        return totalBlocks * blockSize;
    }
}
