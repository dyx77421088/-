package com.example.abc_hz_20191229.util;

import android.util.Log;

import com.example.abc_hz_20191229.R;
import com.example.abc_hz_20191229.model.MyFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MyFileUtils {
    private static int[] img = {
            R.drawable.wenjianjia,//文件夹图片
            R.drawable.wenjianjia2,//文件夹图片(里面有东西)
            R.drawable.ic_launcher_foreground,//非文件夹图片
            R.drawable.txt,//非文件夹图片(.txt的图片)
    };

    /**
     * 根据这个目录，展示该目录下的文件
     */
    public static List<MyFile> show(File file) {
        List<MyFile> list = new ArrayList<>();
        Log.e("??", "路径" + file.getPath());
        File[] files = file.listFiles();
        if (files != null) {
            for (File value : files) {
                //默认为文件夹图片
                MyFile myFile = new MyFile(getName(value.getName()), "", img[0], true, 0, file.getPath());
                if (value.isDirectory()) {
                    //获得文件夹下的东西
                    File[] f2 = value.listFiles();
                    //统计文件夹的个数
                    int number = 0;
                    if (f2 != null) {
                        //设置里面有东西的文件夹图片
                        if(f2.length > 0)
                            myFile.setImg(img[1]);
                        for (File f : f2) {
                            if (f.isDirectory()) number++;
                        }
                        //设置描述(文件夹的个数和非文件夹的个数)
                        myFile.setBottom(number + "个文件夹  " + (f2.length - number) + "个文件");
                    }
                } else {
                    //非文件夹
                    myFile.setImg(img[2]);
                    myFile.setDirectory(false);
                    try {
                        //大小
                        FileInputStream inputStream = new FileInputStream(value);
                        int size = inputStream.available();//获得大小
                        inputStream.close();
                        //获得大小
                        String sizeStr = getSizeString(size);
                        //描述为大小
                        myFile.setBottom(sizeStr);
                        //设置大小
                        myFile.setSize(size);
                        //如果是txt文件设置txt图片
                        if(myFile.getName().length() > 4 && myFile.getName().substring(myFile.getName().length() - 4).equals(".txt")) {
                            myFile.setImg(img[3]);
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                list.add(myFile);
            }
        } else {
            Log.e("???", "????");
        }
        return list;
    }

    public static String getSizeString(long size) {
        String sizeStr;
        DecimalFormat df = new DecimalFormat("#.00");
        if(size<1000){
            sizeStr=size+"B";
        }else if(size<1000 * 1000){
            sizeStr=df.format(size/(double)1000)+"KB";
        }else if(size<1000 * 1000 * 1000){
            sizeStr=df.format(size/(double)(1000 * 1000))+"MB";
        }else{
            sizeStr=df.format(size/(double)(1000 * 1000 * 1000))+"GB";
        }
        return sizeStr;
    }

    /**
     * 判断这个名字是否已经存在了
     */
    public static boolean hasFile(List<MyFile> list, String name, boolean isWenJianJia) {
        for (MyFile myFile : list) {
            if(isWenJianJia && myFile.isDirectory()) {//如果是文件夹
                if(myFile.getName().equals(name)) return true;
            } else if(!isWenJianJia && !myFile.isDirectory()) {//如果不是文件夹
                if(myFile.getName().equals(name)) return true;
            }
        }
        return false;
    }

    /**
     * 删除这个文件夹以及文件夹下的所有文件
     * @param file
     */
    public static void deleteFile(File file) {
        Log.e("删除该文件", "=>" + file.getName());
        if (file.isDirectory()) {//如果是文件夹，就往下找
            File[] files = file.listFiles();
            if(files != null)
                for (File f : files) {
                    deleteFile(f);
                }
            file.delete();//如要保留文件夹，只删除文件，请注释这行
        } else if (file.exists()) {
            file.delete();
        }
    }

    /**
     * 拷贝该目录下的东西到新的目录下
     */
    public static void copy(String oldPath, String newPath) {
        File old = new File(oldPath);
        if(old.isDirectory()) {
            File[] files = old.listFiles();
            if(files != null) {
                for (File file : files) {
                    String p = newPath + "/" + file.getName();//新的东西
                    File theFile = new File(p);
                    if(!theFile.exists()) {//如果它不存在就创建
                        if(file.isDirectory()) {
                            theFile.mkdirs();//创建文件夹
                            copy(file.getPath(), p);//递归创建
                        } else {
                            try {
                                FileInputStream input = new FileInputStream(file);//输入接口
                                FileOutputStream out = new FileOutputStream(theFile);//输出接口
                                byte[] buffer = new byte[1024];
                                int by;
                                while((by = input.read(buffer)) != -1) {//循环写入
                                    out.write(buffer, 0, by);
                                }
                                //关闭资源
                                input.close();
                                out.flush();
                                out.close();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    } else {
                        if(file.isDirectory()) {//如果是文件夹，循环添加
                            copy(file.getPath(), p);//递归创建
                        }
                    }

                }

            }
        } else {
            try {
                FileInputStream input = new FileInputStream(old);//输入接口
                File newF = new File(newPath + "/" + old.getName());
                newF.createNewFile();
                FileOutputStream out = new FileOutputStream(newF);//输出接口
                byte[] buffer = new byte[1024];
                int by;
                while((by = input.read(buffer)) != -1) {//循环写入
                    out.write(buffer, 0, by);
                }
                //关闭资源
                input.close();
                out.flush();
                out.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }


    /**
     * 获得名字(去掉前面的.)
     */
    private static String getName(String name) {
        if(name.charAt(0) == '.') {
            return name.substring(1);
        }
        return name;
    }

    /**
     * @param type 类型(0:按名称 1:按大小)默认为0
     * @param isShengXu  是否为升序 默认为true
     * @return
     */
    public static Comparator<MyFile> getSort(final int type , final boolean isShengXu) {
        return new Comparator<MyFile>() {
            @Override
            public int compare(MyFile o1, MyFile o2) {
                //文件夹优先显示
                if(o1.isDirectory() != o2.isDirectory()) {
                    //大的在前，小的在后
                    return o1.isDirectory() ? -1 : 1;
                } else if(type == 0){//根据名字来排序(不区分大小写)
                    //如果是同一个字母 比如A和a  A和A ...
                    if(o1.getName().toUpperCase().charAt(0) == o2.getName().toUpperCase().charAt(0)) {
                        return isShengXu ? o1.getName().compareTo(o2.getName()) :
                                o2.getName().compareTo(o1.getName());
                    }
                    return isShengXu ? o1.getName().toUpperCase().compareTo(o2.getName().toUpperCase()) :
                            o2.getName().toUpperCase().compareTo(o1.getName().toUpperCase());
                } else if(type == 1) {//按大小
                    return (int)(isShengXu ? o1.getSize() - o2.getSize() : o2.getSize() - o1.getSize());
                }
                return 0;
            }
        };
    }

    public static Comparator<MyFile> getSort() {
        return getSort(0, true);
    }
}
